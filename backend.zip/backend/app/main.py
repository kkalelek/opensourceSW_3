from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.config import get_settings
from app.routers.admin import router as admin_router
from app.routers.availability import router as availability_router

settings = get_settings()


app = FastAPI(
    
    title="Classroom Availability API",
    description="FastAPI backend for IT building classroom availability.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.frontend_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)


app.include_router(availability_router)
app.include_router(admin_router)


@app.get("/", tags=["health"])
def read_root() -> dict[str, str]:
    return {"message": "Classroom Availability API is running."}
