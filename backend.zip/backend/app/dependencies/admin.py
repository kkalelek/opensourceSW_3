from __future__ import annotations

from functools import lru_cache

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from app.config import get_settings
from app.repositories.admin_repository import AdminAccount, AdminRepository
from app.repositories.mysql_admin_repository import MySQLAdminRepository
from app.utils.security import decode_access_token


bearer_scheme = HTTPBearer(auto_error=False)


@lru_cache
def get_admin_repository() -> AdminRepository:
    return MySQLAdminRepository()


def get_optional_override_repository() -> AdminRepository | None:
    if not get_settings().mysql_configured:
        return None
    return get_admin_repository()


def get_current_admin(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    repository: AdminRepository = Depends(get_admin_repository),
) -> AdminAccount:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Admin bearer token is required.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    settings = get_settings()
    if not settings.admin_token_secret:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="ADMIN_TOKEN_SECRET is not configured.",
        )

    try:
        payload = decode_access_token(credentials.credentials, settings.admin_token_secret)
        admin_id = int(payload["sub"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin bearer token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    admin = repository.get_admin_by_id(admin_id)
    if admin is None or not admin.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin bearer token.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return admin
