from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


AvailabilityStatus = Literal["white", "yellow", "green"]
OverrideStatus = Literal["occupied", "available"]


class ScheduleEntry(BaseModel):
    major: str = Field(..., description="Major name")
    course_name: str = Field(..., description="Course name")
    weekday: str = Field(..., description="Original weekday value")
    weekday_code: str = Field(..., description="Normalized weekday code")
    start_time: str = Field(..., description="Class start time")
    end_time: str = Field(..., description="Class end time")
    location: str = Field(..., description="Location string preserved from CSV")
    building: str = Field(..., description="Extracted building name")


class ParsedScheduleSummary(BaseModel):
    building: str = Field(..., description="Supported building name")
    total_entries: int = Field(..., description="Total parsed class entries")
    total_rooms: int = Field(..., description="Unique IT building locations")
    sample_entries: list[ScheduleEntry] = Field(
        default_factory=list,
        description="Sample parsed entries",
    )


class RoomAvailability(BaseModel):
    room: str = Field(..., description="Original location text from CSV")
    status: AvailabilityStatus = Field(..., description="Availability status color")
    base_status: AvailabilityStatus = Field(
        ...,
        description="CSV timetable status before an admin override is applied",
    )
    current_course_name: str | None = Field(
        default=None,
        description="Current course name if a class is in progress",
    )
    current_class_end: str | None = Field(
        default=None,
        description="Current class end time if a class is in progress",
    )
    next_course_name: str | None = Field(
        default=None,
        description="Next course name if one exists later today",
    )
    next_class_start: str | None = Field(
        default=None,
        description="Next class start time if one exists later today",
    )
    available_until: str | None = Field(
        default=None,
        description="Time until the room can be used if currently available",
    )
    availability_message: str | None = Field(
        default=None,
        description="Display message describing current availability",
    )
    is_overridden: bool = Field(
        default=False,
        description="Whether an active admin override changed the final status",
    )
    override_status: OverrideStatus | None = Field(
        default=None,
        description="Active admin override status, if any",
    )
    override_reason: str | None = Field(
        default=None,
        description="Admin override reason, if provided",
    )
    override_expires_at: datetime | None = Field(
        default=None,
        description="Admin override expiration datetime, if provided",
    )


class AvailableNowResponse(BaseModel):
    building: str = Field(..., description="Supported building name")
    day: str = Field(..., description="Normalized weekday code")
    query_time: str = Field(..., description="Current time used for lookup")
    rooms: list[RoomAvailability] = Field(
        default_factory=list,
        description="Current room availability results",
    )


class AvailableRangeRoom(BaseModel):
    room: str = Field(..., description="Original location text from CSV")


class AvailableRangeResponse(BaseModel):
    building: str = Field(..., description="Supported building name")
    day: str = Field(..., description="Normalized weekday code")
    start: str = Field(..., description="Requested start time")
    end: str = Field(..., description="Requested end time")
    rooms: list[AvailableRangeRoom] = Field(
        default_factory=list,
        description="Rooms that do not overlap the requested time range",
    )


class AdminLoginRequest(BaseModel):
    username: str = Field(..., min_length=1, max_length=50)
    password: str = Field(..., min_length=1)


class AdminLoginResponse(BaseModel):
    access_token: str = Field(..., description="Bearer access token")
    token_type: str = Field(default="bearer", description="Token type")


class RoomStatusOverrideRequest(BaseModel):
    building: str = Field(..., min_length=1, max_length=100)
    room: str = Field(..., min_length=1, max_length=255)
    override_status: OverrideStatus
    reason: str | None = Field(default=None, max_length=255)
    expires_at: datetime | None = None


class RoomStatusOverrideDeleteRequest(BaseModel):
    building: str = Field(..., min_length=1, max_length=100)
    room: str = Field(..., min_length=1, max_length=255)


class RoomStatusOverrideResponse(BaseModel):
    id: int
    building: str
    room: str
    override_status: OverrideStatus
    reason: str | None = None
    expires_at: datetime | None = None
    updated_by: int
    created_at: datetime | None = None
    updated_at: datetime | None = None


class RoomStatusOverrideListResponse(BaseModel):
    overrides: list[RoomStatusOverrideResponse] = Field(default_factory=list)


class RoomStatusOverrideDeleteResponse(BaseModel):
    deleted: bool
