from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


def load_env_file() -> None:
    env_path = Path(__file__).resolve().parents[2] / ".env"
    if not env_path.exists():
        return

    for line in env_path.read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, value = stripped.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_env_file()


@dataclass(frozen=True)
class Settings:
    mysql_host: str | None
    mysql_port: int
    mysql_user: str | None
    mysql_password: str | None
    mysql_database: str | None
    admin_token_secret: str | None
    admin_token_expire_minutes: int
    frontend_origins: list[str]

    @property
    def mysql_configured(self) -> bool:
        return all(
            [
                self.mysql_host,
                self.mysql_user,
                self.mysql_password is not None,
                self.mysql_database,
            ]
        )


@lru_cache
def get_settings() -> Settings:
    return Settings(
        mysql_host=os.getenv("MYSQL_HOST"),
        mysql_port=int(os.getenv("MYSQL_PORT", "3306")),
        mysql_user=os.getenv("MYSQL_USER"),
        mysql_password=os.getenv("MYSQL_PASSWORD"),
        mysql_database=os.getenv("MYSQL_DATABASE"),
        admin_token_secret=os.getenv("ADMIN_TOKEN_SECRET"),
        admin_token_expire_minutes=int(os.getenv("ADMIN_TOKEN_EXPIRE_MINUTES", "120")),
        frontend_origins=_parse_csv_env(
            os.getenv("FRONTEND_ORIGINS"),
            default=["http://localhost:5173"],
        ),
    )


def _parse_csv_env(value: str | None, *, default: list[str]) -> list[str]:
    if value is None:
        return default
    parsed = [item.strip() for item in value.split(",") if item.strip()]
    return parsed or default
