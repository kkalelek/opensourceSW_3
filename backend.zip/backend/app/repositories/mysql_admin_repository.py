from __future__ import annotations

from datetime import datetime
from typing import Any

from app.config import get_settings
from app.repositories.admin_repository import AdminAccount, RoomStatusOverride


class MySQLAdminRepository:
    def _connect(self) -> Any:
        settings = get_settings()
        if not settings.mysql_configured:
            raise RuntimeError("MySQL environment variables are not configured.")

        import pymysql
        import pymysql.cursors

        return pymysql.connect(
            host=settings.mysql_host,
            port=settings.mysql_port,
            user=settings.mysql_user,
            password=settings.mysql_password,
            database=settings.mysql_database,
            charset="utf8mb4",
            autocommit=True,
            cursorclass=pymysql.cursors.DictCursor,
        )

    def get_admin_by_id(self, admin_id: int) -> AdminAccount | None:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, username, password_hash, is_active
                    FROM admins
                    WHERE id = %s
                    """,
                    (admin_id,),
                )
                row = cursor.fetchone()
        return self._build_admin(row)

    def get_admin_by_username(self, username: str) -> AdminAccount | None:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, username, password_hash, is_active
                    FROM admins
                    WHERE username = %s
                    """,
                    (username,),
                )
                row = cursor.fetchone()
        return self._build_admin(row)

    def create_admin(self, username: str, password_hash: str) -> AdminAccount:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO admins (username, password_hash)
                    VALUES (%s, %s)
                    """,
                    (username, password_hash),
                )
                admin_id = cursor.lastrowid

        admin = self.get_admin_by_id(admin_id)
        if admin is None:
            raise RuntimeError("Admin account was not created.")
        return admin

    def list_room_status_overrides(
        self,
        building: str | None = None,
    ) -> list[RoomStatusOverride]:
        params: tuple[Any, ...] = ()
        where_clause = ""
        if building is not None:
            where_clause = "WHERE building = %s"
            params = (building,)

        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    f"""
                    SELECT id, building, room, override_status, reason, expires_at,
                           updated_by, created_at, updated_at
                    FROM room_status_overrides
                    {where_clause}
                    ORDER BY building, room
                    """,
                    params,
                )
                rows = cursor.fetchall()

        return [self._build_override(row) for row in rows]

    def upsert_room_status_override(
        self,
        *,
        building: str,
        room: str,
        override_status: str,
        reason: str | None,
        expires_at: datetime | None,
        updated_by: int,
    ) -> RoomStatusOverride:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    INSERT INTO room_status_overrides
                        (building, room, override_status, reason, expires_at, updated_by)
                    VALUES (%s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                        override_status = VALUES(override_status),
                        reason = VALUES(reason),
                        expires_at = VALUES(expires_at),
                        updated_by = VALUES(updated_by)
                    """,
                    (building, room, override_status, reason, expires_at, updated_by),
                )

        return self._get_room_status_override(building=building, room=room)

    def delete_room_status_override(self, *, building: str, room: str) -> bool:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    DELETE FROM room_status_overrides
                    WHERE building = %s AND room = %s
                    """,
                    (building, room),
                )
                return cursor.rowcount > 0

    def _get_room_status_override(
        self,
        *,
        building: str,
        room: str,
    ) -> RoomStatusOverride:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    SELECT id, building, room, override_status, reason, expires_at,
                           updated_by, created_at, updated_at
                    FROM room_status_overrides
                    WHERE building = %s AND room = %s
                    """,
                    (building, room),
                )
                row = cursor.fetchone()

        if row is None:
            raise RuntimeError("Room status override was not saved.")
        return self._build_override(row)

    def _build_admin(self, row: dict[str, Any] | None) -> AdminAccount | None:
        if row is None:
            return None
        return AdminAccount(
            id=int(row["id"]),
            username=str(row["username"]),
            password_hash=str(row["password_hash"]),
            is_active=bool(row["is_active"]),
        )

    def _build_override(self, row: dict[str, Any]) -> RoomStatusOverride:
        return RoomStatusOverride(
            id=int(row["id"]),
            building=str(row["building"]),
            room=str(row["room"]),
            override_status=str(row["override_status"]),
            reason=row["reason"],
            expires_at=row["expires_at"],
            updated_by=int(row["updated_by"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )
