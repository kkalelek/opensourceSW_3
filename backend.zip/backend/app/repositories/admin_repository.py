from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol


@dataclass(frozen=True)
class AdminAccount:
    id: int
    username: str
    password_hash: str
    is_active: bool


@dataclass(frozen=True)
class RoomStatusOverride:
    id: int
    building: str
    room: str
    override_status: str
    reason: str | None
    expires_at: datetime | None
    updated_by: int
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AdminRepository(Protocol):
    def get_admin_by_id(self, admin_id: int) -> AdminAccount | None:
        ...

    def get_admin_by_username(self, username: str) -> AdminAccount | None:
        ...

    def create_admin(self, username: str, password_hash: str) -> AdminAccount:
        ...

    def list_room_status_overrides(
        self,
        building: str | None = None,
    ) -> list[RoomStatusOverride]:
        ...

    def upsert_room_status_override(
        self,
        *,
        building: str,
        room: str,
        override_status: str,
        reason: str | None,
        expires_at: datetime | None,
        updated_by: int,
    ) -> RoomStatusOverride:
        ...

    def delete_room_status_override(self, *, building: str, room: str) -> bool:
        ...
