from __future__ import annotations

from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, status

from app.config import get_settings
from app.dependencies.admin import get_admin_repository, get_current_admin
from app.repositories.admin_repository import AdminAccount, AdminRepository, RoomStatusOverride
from app.schemas.availability import (
    AdminLoginRequest,
    AdminLoginResponse,
    RoomStatusOverrideDeleteRequest,
    RoomStatusOverrideDeleteResponse,
    RoomStatusOverrideListResponse,
    RoomStatusOverrideRequest,
    RoomStatusOverrideResponse,
)
from app.services.timetable_service import get_timetable_service
from app.utils.constants import SUPPORTED_BUILDING
from app.utils.security import create_access_token, verify_password
from app.utils.time_utils import get_current_seoul_datetime, normalize_to_seoul_naive

router = APIRouter(prefix="/api/admin", tags=["admin"])


@router.post("/login", response_model=AdminLoginResponse)
def login_admin(
    request: AdminLoginRequest,
    repository: AdminRepository = Depends(get_admin_repository),
) -> AdminLoginResponse:
    settings = get_settings()
    if not settings.admin_token_secret:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="ADMIN_TOKEN_SECRET is not configured.",
        )

    admin = repository.get_admin_by_username(request.username)
    if (
        admin is None
        or not admin.is_active
        or not verify_password(request.password, admin.password_hash)
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = create_access_token(
        subject=str(admin.id),
        secret=settings.admin_token_secret,
        expires_delta=timedelta(minutes=settings.admin_token_expire_minutes),
    )
    return AdminLoginResponse(access_token=token)


@router.get(
    "/room-status-overrides",
    response_model=RoomStatusOverrideListResponse,
)
def list_room_status_overrides(
    _: AdminAccount = Depends(get_current_admin),
    repository: AdminRepository = Depends(get_admin_repository),
) -> RoomStatusOverrideListResponse:
    overrides = repository.list_room_status_overrides()
    return RoomStatusOverrideListResponse(
        overrides=[_build_override_response(override) for override in overrides]
    )


@router.put(
    "/room-status-override",
    response_model=RoomStatusOverrideResponse,
)
def upsert_room_status_override(
    request: RoomStatusOverrideRequest,
    current_admin: AdminAccount = Depends(get_current_admin),
    repository: AdminRepository = Depends(get_admin_repository),
) -> RoomStatusOverrideResponse:
    _validate_supported_building(request.building)
    _validate_existing_room(request.room)
    expires_at = _normalize_and_validate_expires_at(request.expires_at)
    override = repository.upsert_room_status_override(
        building=request.building,
        room=request.room,
        override_status=request.override_status,
        reason=request.reason,
        expires_at=expires_at,
        updated_by=current_admin.id,
    )
    return _build_override_response(override)


@router.delete(
    "/room-status-override",
    response_model=RoomStatusOverrideDeleteResponse,
)
def delete_room_status_override(
    request: RoomStatusOverrideDeleteRequest,
    _: AdminAccount = Depends(get_current_admin),
    repository: AdminRepository = Depends(get_admin_repository),
) -> RoomStatusOverrideDeleteResponse:
    _validate_supported_building(request.building)
    deleted = repository.delete_room_status_override(
        building=request.building,
        room=request.room,
    )
    return RoomStatusOverrideDeleteResponse(deleted=deleted)


def _validate_supported_building(building: str) -> None:
    if building != SUPPORTED_BUILDING:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Only {SUPPORTED_BUILDING} is supported.",
        )


def _validate_existing_room(room: str) -> None:
    service = get_timetable_service()
    if room not in service.list_room_names():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Room does not exist in the CSV timetable for IT융합대학.",
        )


def _normalize_and_validate_expires_at(expires_at: datetime | None) -> datetime | None:
    if expires_at is None:
        return None

    normalized = normalize_to_seoul_naive(expires_at)
    if normalized <= get_current_seoul_datetime():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="expires_at must be a future datetime in Asia/Seoul.",
        )
    return normalized


def _build_override_response(
    override: RoomStatusOverride,
) -> RoomStatusOverrideResponse:
    return RoomStatusOverrideResponse(
        id=override.id,
        building=override.building,
        room=override.room,
        override_status=override.override_status,
        reason=override.reason,
        expires_at=override.expires_at,
        updated_by=override.updated_by,
        created_at=override.created_at,
        updated_at=override.updated_at,
    )
