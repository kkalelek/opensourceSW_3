from __future__ import annotations

import argparse
import getpass
import sys
from pathlib import Path


BACKEND_DIR = Path(__file__).resolve().parents[1]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

from app.repositories.mysql_admin_repository import MySQLAdminRepository
from app.utils.security import hash_password


def main() -> None:
    parser = argparse.ArgumentParser(description="Create the first admin account.")
    parser.add_argument("--username", required=True, help="Admin username")
    parser.add_argument("--password", help="Admin password. Omit to enter securely.")
    args = parser.parse_args()

    password = args.password or getpass.getpass("Admin password: ")
    if not password:
        raise SystemExit("Password is required.")

    repository = MySQLAdminRepository()
    admin = repository.create_admin(
        username=args.username,
        password_hash=hash_password(password),
    )
    print(f"Created admin account: {admin.username} (id={admin.id})")


if __name__ == "__main__":
    main()
