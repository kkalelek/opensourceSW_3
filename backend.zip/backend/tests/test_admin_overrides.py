from __future__ import annotations

from datetime import datetime, time, timezone
from typing import get_args

import pytest
from fastapi import HTTPException

from app.config import get_settings
from app.dependencies.admin import get_current_admin
import app.routers.admin as admin_router
from app.repositories.admin_repository import AdminAccount, RoomStatusOverride
from app.routers.admin import (
    delete_room_status_override,
    login_admin,
    upsert_room_status_override,
)
from app.schemas.availability import (
    AdminLoginRequest,
    AvailabilityStatus,
    OverrideStatus,
    RoomStatusOverrideDeleteRequest,
    RoomStatusOverrideRequest,
)
from app.services.timetable_service import ParsedClassTime, TimetableService
from app.utils.security import hash_password


BUILDING = "IT\uC735\uD569\uB300\uD559"
ROOM = "IT\uC735\uD569\uB300\uD559-TEST(1001)"


class FakeAdminRepository:
    def __init__(self) -> None:
        self.admin = AdminAccount(
            id=1,
            username="admin",
            password_hash=hash_password("secret"),
            is_active=True,
        )
        self.overrides: dict[tuple[str, str], RoomStatusOverride] = {}
        self.next_override_id = 1

    def get_admin_by_id(self, admin_id: int) -> AdminAccount | None:
        if admin_id == self.admin.id:
            return self.admin
        return None

    def get_admin_by_username(self, username: str) -> AdminAccount | None:
        if username == self.admin.username:
            return self.admin
        return None

    def create_admin(self, username: str, password_hash: str) -> AdminAccount:
        self.admin = AdminAccount(
            id=self.admin.id + 1,
            username=username,
            password_hash=password_hash,
            is_active=True,
        )
        return self.admin

    def list_room_status_overrides(
        self,
        building: str | None = None,
    ) -> list[RoomStatusOverride]:
        overrides = list(self.overrides.values())
        if building is None:
            return overrides
        return [override for override in overrides if override.building == building]

    def upsert_room_status_override(
        self,
        *,
        building: str,
        room: str,
        override_status: str,
        reason: str | None,
        expires_at: datetime | None,
        updated_by: int,
    ) -> RoomStatusOverride:
        key = (building, room)
        override = RoomStatusOverride(
            id=self.overrides.get(key).id if key in self.overrides else self.next_override_id,
            building=building,
            room=room,
            override_status=override_status,
            reason=reason,
            expires_at=expires_at,
            updated_by=updated_by,
            created_at=datetime(2026, 5, 18, 9, 0),
            updated_at=datetime(2026, 5, 18, 9, 0),
        )
        if key not in self.overrides:
            self.next_override_id += 1
        self.overrides[key] = override
        return override

    def delete_room_status_override(self, *, building: str, room: str) -> bool:
        return self.overrides.pop((building, room), None) is not None


@pytest.fixture(autouse=True)
def admin_test_settings(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("ADMIN_TOKEN_SECRET", "test-secret")
    monkeypatch.setenv("ADMIN_TOKEN_EXPIRE_MINUTES", "60")
    monkeypatch.setattr(
        admin_router,
        "get_timetable_service",
        lambda: type("FakeTimetableService", (), {"list_room_names": lambda self: [ROOM]})(),
    )
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def build_service(entries: list[ParsedClassTime]) -> TimetableService:
    service = TimetableService.__new__(TimetableService)
    service.csv_path = None
    service._entries = sorted(
        entries,
        key=lambda entry: (entry.location, entry.weekday_code, entry.start_time, entry.end_time),
    )
    return service


def build_entry(*, course_name: str, start_hour: int, end_hour: int) -> ParsedClassTime:
    return ParsedClassTime(
        major="Test Major",
        course_name=course_name,
        weekday="\uC6D4",
        weekday_code="MON",
        start_time=time(start_hour, 0),
        end_time=time(end_hour, 0),
        location=ROOM,
        building=BUILDING,
    )


def get_first_room(
    service: TimetableService,
    repository: FakeAdminRepository,
    *,
    current_datetime: datetime,
):
    result = service._build_available_now_response(
        building=BUILDING,
        day_code="MON",
        current_time=current_datetime.time(),
        current_datetime=current_datetime,
        override_repository=repository,
    )
    return result.rooms[0]


def test_admin_login_success_returns_bearer_token() -> None:
    repository = FakeAdminRepository()

    result = login_admin(
        AdminLoginRequest(username="admin", password="secret"),
        repository=repository,
    )

    assert result.token_type == "bearer"
    assert result.access_token


def test_admin_login_fails_with_wrong_password() -> None:
    repository = FakeAdminRepository()

    with pytest.raises(HTTPException) as exc:
        login_admin(
            AdminLoginRequest(username="admin", password="wrong"),
            repository=repository,
        )

    assert exc.value.status_code == 401


def test_admin_override_api_fails_without_token() -> None:
    repository = FakeAdminRepository()

    with pytest.raises(HTTPException) as exc:
        get_current_admin(credentials=None, repository=repository)

    assert exc.value.status_code == 401


def test_frontend_origins_are_loaded_from_environment(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv(
        "FRONTEND_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173",
    )
    get_settings.cache_clear()

    assert get_settings().frontend_origins == [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]


def test_occupied_override_changes_empty_room_to_white() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Networks", start_hour=16, end_hour=17)])
    repository.upsert_room_status_override(
        building=BUILDING,
        room=ROOM,
        override_status="occupied",
        reason="관리자 점검",
        expires_at=None,
        updated_by=1,
    )

    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert room.base_status == "green"
    assert room.status == "white"
    assert room.is_overridden is True
    assert room.override_status == "occupied"
    assert room.available_until is None
    assert room.availability_message == "관리자에 의해 사용 중으로 변경됨"


def test_available_override_changes_busy_room_to_green() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Algorithms", start_hour=13, end_hour=15)])
    repository.upsert_room_status_override(
        building=BUILDING,
        room=ROOM,
        override_status="available",
        reason="수업 취소",
        expires_at=None,
        updated_by=1,
    )

    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert room.base_status == "white"
    assert room.status == "green"
    assert room.is_overridden is True
    assert room.override_status == "available"
    assert room.available_until is None
    assert room.availability_message == "관리자에 의해 사용 가능으로 변경됨"


def test_no_red_status_is_defined() -> None:
    assert "red" not in get_args(AvailabilityStatus)
    assert "red" not in get_args(OverrideStatus)


def test_null_reason_and_expires_at_are_saved_and_applied() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Networks", start_hour=16, end_hour=17)])
    override = upsert_room_status_override(
        RoomStatusOverrideRequest(
            building=BUILDING,
            room=ROOM,
            override_status="available",
            reason=None,
            expires_at=None,
        ),
        current_admin=repository.admin,
        repository=repository,
    )

    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert override.reason is None
    assert override.expires_at is None
    assert room.override_reason is None
    assert room.override_expires_at is None
    assert room.availability_message == "관리자에 의해 사용 가능으로 변경됨"


def test_override_rejects_room_not_found_in_csv() -> None:
    repository = FakeAdminRepository()

    with pytest.raises(HTTPException) as exc:
        upsert_room_status_override(
            RoomStatusOverrideRequest(
                building=BUILDING,
                room="IT\uC735\uD569\uB300\uD559-NOT-FOUND(9999)",
                override_status="available",
                reason=None,
                expires_at=None,
            ),
            current_admin=repository.admin,
            repository=repository,
        )

    assert exc.value.status_code == 404
    assert repository.overrides == {}


def test_override_rejects_past_expires_at() -> None:
    repository = FakeAdminRepository()

    with pytest.raises(HTTPException) as exc:
        upsert_room_status_override(
            RoomStatusOverrideRequest(
                building=BUILDING,
                room=ROOM,
                override_status="available",
                reason=None,
                expires_at=datetime(2000, 1, 1, 12, 0),
            ),
            current_admin=repository.admin,
            repository=repository,
        )

    assert exc.value.status_code == 400
    assert repository.overrides == {}


def test_override_normalizes_timezone_aware_expires_at_to_seoul() -> None:
    repository = FakeAdminRepository()

    override = upsert_room_status_override(
        RoomStatusOverrideRequest(
            building=BUILDING,
            room=ROOM,
            override_status="available",
            reason=None,
            expires_at=datetime(2099, 1, 1, 8, 0, tzinfo=timezone.utc),
        ),
        current_admin=repository.admin,
        repository=repository,
    )

    assert override.expires_at == datetime(2099, 1, 1, 17, 0)


def test_available_override_with_expires_at_sets_until_and_message() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Algorithms", start_hour=13, end_hour=15)])
    expires_at = datetime(2026, 5, 18, 17, 0)
    repository.upsert_room_status_override(
        building=BUILDING,
        room=ROOM,
        override_status="available",
        reason="수업 취소",
        expires_at=expires_at,
        updated_by=1,
    )

    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert room.status == "green"
    assert room.available_until == "17:00"
    assert room.availability_message == "17:00까지 사용 가능 (관리자 수정)"
    assert room.override_expires_at == expires_at


def test_expired_override_is_not_applied() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Algorithms", start_hour=13, end_hour=15)])
    repository.upsert_room_status_override(
        building=BUILDING,
        room=ROOM,
        override_status="available",
        reason="만료됨",
        expires_at=datetime(2026, 5, 18, 13, 0),
        updated_by=1,
    )

    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert room.base_status == "white"
    assert room.status == "white"
    assert room.is_overridden is False
    assert room.override_status is None


def test_delete_override_restores_csv_status() -> None:
    repository = FakeAdminRepository()
    service = build_service([build_entry(course_name="Algorithms", start_hour=13, end_hour=15)])
    repository.upsert_room_status_override(
        building=BUILDING,
        room=ROOM,
        override_status="available",
        reason="수업 취소",
        expires_at=None,
        updated_by=1,
    )

    deleted = delete_room_status_override(
        RoomStatusOverrideDeleteRequest(building=BUILDING, room=ROOM),
        repository=repository,
    )
    room = get_first_room(
        service,
        repository,
        current_datetime=datetime(2026, 5, 18, 14, 0),
    )

    assert deleted.deleted is True
    assert room.base_status == "white"
    assert room.status == "white"
    assert room.is_overridden is False
