CREATE DATABASE IF NOT EXISTS empty_classroom
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE empty_classroom;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS room_status_overrides (
  id INT AUTO_INCREMENT PRIMARY KEY,
  building VARCHAR(100) NOT NULL,
  room VARCHAR(255) NOT NULL,
  override_status ENUM('occupied', 'available') NOT NULL,
  reason VARCHAR(255) NULL,
  expires_at DATETIME NULL,
  updated_by INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_room_status_overrides_admin
    FOREIGN KEY (updated_by) REFERENCES admins(id),
  CONSTRAINT uq_room_status_overrides_building_room
    UNIQUE (building, room)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
